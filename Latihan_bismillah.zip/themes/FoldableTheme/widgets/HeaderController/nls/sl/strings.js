define({
  "_widgetLabel": "Kontrolnik glave",
  "signin": "Prijava",
  "signout": "Odjava",
  "about": "Več o tem",
  "signInTo": "Prijava v",
  "cantSignOutTip": "Ta funkcija v načinu predogleda ni na voljo.",
  "more": "več"
});